import React, { useState } from 'react';
import { 
  Heart, 
  Video, 
  Home, 
  Calendar, 
  MapPin, 
  Gift, 
  Camera, 
  UserCheck,
  Phone,
  Send,
  Car,
  Info,
  Mail,
  User,
  Clock
} from 'lucide-react';

type Event = {
  title: string;
  date: string;
  time: string;
  description: string;
};

const events: Event[] = [
  {
    title: "Gaye Holud",
    date: "19th April 2025",
    time: "4:00 PM",
    description: "A traditional turmeric ceremony where friends and family apply turmeric paste on the bride and groom for a pre-wedding glow."
  },
  {
    title: "Wedding Ceremony",
    date: "20th April 2025",
    time: "6:30 PM",
    description: "Join us for our wedding ceremony as we exchange vows and celebrate our love with those closest to us."
  },
  {
    title: "Reception",
    date: "21st April 2025",
    time: "7:00 PM",
    description: "An evening of celebration, dancing, and dinner to honor our new journey together."
  }
];

function App() {
  const [activeTab, setActiveTab] = useState('home');
  const [rsvpStep, setRsvpStep] = useState(1);
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: ''
  });

  const renderContent = () => {
    switch (activeTab) {
      case 'events':
        return (
          <div className="space-y-8">
            {events.map((event) => (
              <div key={event.title} className="bg-white/10 backdrop-blur-lg rounded-2xl p-6">
                <h2 className="text-2xl text-golden font-dancing mb-4">{event.title}</h2>
                <div className="flex items-center gap-2 text-white mb-2">
                  <Calendar size={18} />
                  <span>{event.date}</span>
                </div>
                <div className="flex items-center gap-2 text-white mb-4">
                  <Clock size={18} />
                  <span>{event.time}</span>
                </div>
                <p className="text-white/90">{event.description}</p>
              </div>
            ))}
          </div>
        );

      case 'venue':
        return (
          <div className="bg-white/10 backdrop-blur-lg rounded-2xl p-6">
            <h2 className="text-3xl text-golden font-dancing mb-6">Our Venue</h2>
            <div className="text-white">
              <div className="flex items-start gap-3 mb-4">
                <MapPin className="text-golden mt-1" />
                <div>
                  <h3 className="text-xl text-golden mb-2">ITC Royal Bengal</h3>
                  <p>1, JBS Haldane Ave, Kolkata, West Bengal 700105</p>
                </div>
              </div>
              <p className="mb-6">Nestled in the heart of Kolkata, ITC Royal Bengal stands as a testament to the rich Bengali heritage.</p>
              <div className="flex gap-4">
                <button className="flex items-center gap-2 px-6 py-3 bg-black text-white rounded-full">
                  <Send size={18} />
                  Directions
                </button>
                <button className="flex items-center gap-2 px-6 py-3 bg-black text-white rounded-full">
                  <Car size={18} />
                  Book Uber
                </button>
              </div>
            </div>
          </div>
        );

      case 'gifts':
        return (
          <div className="bg-white/10 backdrop-blur-lg rounded-2xl p-6">
            <h2 className="text-3xl text-golden font-dancing mb-6">Share Your Blessings</h2>
            <div className="text-center text-white">
              <p className="mb-8">In lieu of traditional gifts, we request your blessings in the form of a contribution that will support orphanages and charitable homes.</p>
              <div className="flex justify-center mb-8">
                <Heart className="text-red-500" size={48} />
              </div>
              <h3 className="text-2xl text-golden font-dancing mb-6">Digital Shagun</h3>
              <button className="w-full mb-6 bg-red-500 text-white py-3 rounded-full">
                Send via GPay
              </button>
              <p className="mb-4">GPay Number: 7547000962</p>
              <div className="flex items-start gap-2 text-sm text-white/80">
                <Info size={16} className="mt-1" />
                <p>Your contribution will be donated to support orphanages and charitable homes. We appreciate your generosity in helping us make a difference.</p>
              </div>
            </div>
          </div>
        );

      case 'photos':
        return (
          <div className="bg-white/10 backdrop-blur-lg rounded-2xl p-6">
            <h2 className="text-3xl text-golden font-dancing mb-2">Upload Photo</h2>
            <p className="text-white/80 mb-6">Share your special moments with us</p>
            <div className="border-2 border-dashed border-white/30 rounded-lg p-8 text-center">
              <Camera size={48} className="mx-auto mb-4 text-white/60" />
              <p className="text-white mb-4">Click here to upload your photos</p>
              <input type="file" className="hidden" accept="image/*" />
            </div>
          </div>
        );

      case 'rsvp':
        return (
          <div className="bg-white/10 backdrop-blur-lg rounded-2xl p-6">
            <h2 className="text-3xl text-golden font-dancing mb-6">Let Us Know You're Coming</h2>
            <div className="flex justify-center gap-2 mb-8">
              {[1, 2, 3, 4].map((step) => (
                <div
                  key={step}
                  className={`w-2 h-2 rounded-full ${
                    step === rsvpStep ? 'bg-golden' : 'bg-white/30'
                  }`}
                />
              ))}
            </div>
            <form className="space-y-6">
              <div>
                <label className="text-white mb-2 block">Your Name</label>
                <div className="relative">
                  <User className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={20} />
                  <input
                    type="text"
                    placeholder="Enter your full name"
                    className="w-full pl-10 pr-4 py-3 bg-white/10 rounded-lg text-white placeholder-gray-400"
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  />
                </div>
              </div>
              <div>
                <label className="text-white mb-2 block">Email</label>
                <div className="relative">
                  <Mail className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={20} />
                  <input
                    type="email"
                    placeholder="Enter your email"
                    className="w-full pl-10 pr-4 py-3 bg-white/10 rounded-lg text-white placeholder-gray-400"
                    value={formData.email}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                  />
                </div>
              </div>
              <div>
                <label className="text-white mb-2 block">Phone Number</label>
                <div className="relative">
                  <Phone className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={20} />
                  <input
                    type="tel"
                    placeholder="Enter your phone number"
                    className="w-full pl-10 pr-4 py-3 bg-white/10 rounded-lg text-white placeholder-gray-400"
                    value={formData.phone}
                    onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                  />
                </div>
              </div>
              <button
                type="submit"
                className="w-full bg-golden text-purple-900 py-3 rounded-full font-medium"
              >
                Continue
              </button>
            </form>
          </div>
        );

      default:
        return (
          <div className="max-w-2xl mx-auto bg-white/10 backdrop-blur-lg rounded-2xl p-8 shadow-xl">
            <h1 className="text-4xl md:text-5xl text-golden text-center font-dancing mb-6">
              Anaya & Arjun
            </h1>
            
            <p className="text-white text-center text-lg mb-8">
              Request the pleasure of your company as we celebrate our wedding
            </p>

            <div className="text-golden text-center text-2xl font-dancing mb-8">
              April 20th, 2025
            </div>

            <div className="flex flex-col md:flex-row gap-4 justify-center mb-12">
              <button className="flex items-center justify-center gap-2 px-6 py-3 bg-golden text-purple-900 rounded-full hover:bg-golden/90 transition-colors">
                <Video size={20} />
                Watch Our Story
              </button>
              <button 
                className="flex items-center justify-center gap-2 px-6 py-3 bg-white text-purple-900 rounded-full hover:bg-white/90 transition-colors"
                onClick={() => setActiveTab('rsvp')}
              >
                <UserCheck size={20} />
                RSVP Now
              </button>
            </div>
          </div>
        );
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-500 to-pink-500">
      {/* Header */}
      <header className="pt-8 pb-4 text-center">
        <div className="text-4xl font-dancing text-golden animate-fade-in">
          A&A
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-8">
        {renderContent()}
      </main>

      {/* Floating Call Button */}
      <button className="fixed bottom-24 right-4 w-12 h-12 bg-golden rounded-full flex items-center justify-center shadow-lg hover:bg-golden/90 transition-colors">
        <Phone size={24} className="text-purple-900" />
      </button>

      {/* Navigation Bar */}
      <nav className="fixed bottom-0 left-0 right-0 bg-white/10 backdrop-blur-lg p-4">
        <div className="container mx-auto">
          <div className="flex justify-around items-center">
            {[
              { icon: Home, label: 'Home' },
              { icon: Calendar, label: 'Events' },
              { icon: MapPin, label: 'Venue' },
              { icon: Gift, label: 'Gifts' },
              { icon: Camera, label: 'Photos' },
              { icon: UserCheck, label: 'RSVP' }
            ].map(({ icon: Icon, label }) => (
              <button
                key={label}
                onClick={() => setActiveTab(label.toLowerCase())}
                className={`flex flex-col items-center gap-1 ${
                  activeTab === label.toLowerCase()
                    ? 'text-golden'
                    : 'text-white'
                }`}
              >
                <Icon size={20} />
                <span className="text-xs">{label}</span>
              </button>
            ))}
          </div>
        </div>
      </nav>
    </div>
  );
}

export default App;